package validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Validator3 {
	
	public static boolean isValid(HashMap<String,WebService> repository, Taxonomy taxonomy, HashSet<String> providedInstances, HashSet<String> targetInstances, Node node){
		HashSet<String> obtainedInstances=new HashSet();
		for (String providedInstance:providedInstances)
			obtainedInstances.addAll(taxonomy.getNewAncestorsInstances(providedInstance,obtainedInstances));
		HashSet<String> outputInstances = getOutputs(repository, taxonomy, obtainedInstances, node);
		if (outputInstances==null)
			return false;
		for (String instanceName:targetInstances)
			if (!outputInstances.contains(instanceName))
				return false;
		return true;
	}
	
	public static HashSet<String> getOutputs(HashMap<String,WebService> repository, Taxonomy taxonomy, HashSet<String> providedInstances, Node node){
		if (node.getNodeName().equals(Constants.sequenceString))
			return getOutputsFromSequence(repository, taxonomy, providedInstances, node);
		if (node.getNodeName().equals(Constants.parallelString))
			return getOutputsFromParallel(repository, taxonomy, providedInstances, node);
		if (node.getNodeName().equals(Constants.serviceDescString))
			return getOutputsFromServiceDesc(repository, taxonomy, providedInstances, node);
		return null;
	}
	
	//de lucrat la astea 3 chestii
	private static HashSet<String> getOutputsFromSequence(HashMap<String,WebService> repository, Taxonomy taxonomy, HashSet<String> providedInstances, Node node){
		HashSet<String> outputInstances =(HashSet<String>)providedInstances.clone();
		NodeList childs = node.getChildNodes();
		for (int index=0;index<childs.getLength();index++){
			Node childNode=childs.item(index);
			if (childNode.getNodeName().equals(Constants.serviceDescString) || childNode.getNodeName().equals(Constants.sequenceString) || childNode.getNodeName().equals(Constants.parallelString)){
				HashSet<String> outs=getOutputs(repository, taxonomy, outputInstances, childNode);
				//System.out.println("b");
				if (outs==null)
					return null;
				outputInstances.addAll(outs);
			}
		}
		return outputInstances;
	}
	
	private static HashSet<String> getOutputsFromParallel(HashMap<String,WebService> repository, Taxonomy taxonomy, HashSet<String> providedInstances, Node node){
		HashSet<String> outputInstances =(HashSet<String>)providedInstances.clone();
		NodeList childs = node.getChildNodes();
		for (int index=0;index<childs.getLength();index++){
			Node childNode=childs.item(index);
			if (childNode.getNodeName().equals(Constants.serviceDescString) || childNode.getNodeName().equals(Constants.sequenceString) || childNode.getNodeName().equals(Constants.parallelString)){
				HashSet<String> outs=getOutputs(repository, taxonomy, providedInstances, childNode);
				if (outs==null)
					return null;
				outputInstances.addAll(outs);
			}
		}
		return outputInstances;
	}
	
	private static HashSet<String> getOutputsFromServiceDesc(HashMap<String,WebService> repository, Taxonomy taxonomy, HashSet<String> providedInstances, Node node){
		//aici de avut grija
		ServiceDesc serviceDesc=new ServiceDesc(node);
		HashSet<String> outputInstances =(HashSet<String>)providedInstances.clone();
		String firstServiceName = serviceDesc.getRealizationsServices().get(0);
		WebService firstService = repository.get(firstServiceName);
		for (String inputInstance:firstService.getInputs())
			if (!providedInstances.contains(inputInstance)){
				System.out.println(inputInstance);
				return null;
			}
		for (String outputInstanceName:firstService.getOutputs())
				outputInstances.addAll(taxonomy.getNewAncestorsInstances(outputInstanceName, outputInstances));//aici
		return outputInstances;
	}
}

