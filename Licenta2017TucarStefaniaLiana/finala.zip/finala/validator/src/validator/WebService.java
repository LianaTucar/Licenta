/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validator;


import java.util.HashSet;

/**
 *
 * @author paul
 */
public class WebService implements Comparable{
    
    private HashSet<String> inputs, outputs, neededInputs, newOutputs;
    private String name;
    
    public WebService(String sName, HashSet<String> inps, HashSet<String> outs) {
    	name=sName;
        inputs = inps;
        neededInputs=(HashSet<String>)inputs.clone();
        outputs = outs;
        newOutputs=(HashSet<String>)outputs.clone();
    }
    
    public void resetNeededInputsAndNewOutputs(){
    	neededInputs=(HashSet<String>)inputs.clone();
    	newOutputs=(HashSet<String>)outputs.clone();
    }
    
    public void removeFromNewOutputs(HashSet<String> instances){
    	newOutputs.removeAll(instances);
    }
    
    public void removeFromNewOutputs(String instance){
    	newOutputs.remove(instance);
    }
    
    public int getNumberOfNewOutputs(){
    	return newOutputs.size();
    }
    
    public int getNumberOfInputs(){
    	return inputs.size();
    }
    
    public boolean removeNeededInput(String instanceName){
    	return neededInputs.remove(instanceName);
    }
    
    public int getNumberOfNeddedInputs(){
    	return neededInputs.size();
    }
    
    HashSet<String> getInputs() {
        return inputs;
    }
    
    HashSet<String> getOutputs() {
        return outputs;
    }

	public String getName() {
		return name;
	}

	@Override
	public boolean equals(Object b){
		return this.name.equals(((WebService)b).getName());
	}
	
	@Override
	public int compareTo(Object arg0) {
		WebService b = (WebService)arg0;
		float myScore=this.getNumberOfNewOutputs();
		float bScore =b.getNumberOfNewOutputs();
		//float myScore=this.getNumberOfNewOutputs()/(this.getNumberOfInputs()+1);
		//float bScore =b.getNumberOfNewOutputs()/(b.getNumberOfInputs()+1);
		if (myScore<bScore)
			return -1;
		if (myScore>bScore)
			return 1; ///asa sau invers?????????????????????????????????????????????????????????????????????????????
		return 0;
	}

	/*public void setNeededInputs(HashSet<String> neededInputs) {
		this.neededInputs = neededInputs;
	}*/

	public HashSet<String> getNeededInputs() {
		return neededInputs;
	}

	public HashSet<String> getNewOutputs() {
		return newOutputs;
	}
    
   /* @Override
    public int hashCode(){
    	return name.hashCode();
    }*/
}
