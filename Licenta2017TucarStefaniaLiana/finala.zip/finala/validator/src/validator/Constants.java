package validator;

public class Constants {
	public static final String sequenceString="sequence";
	public static final String parallelString="parallel";
	public static final String serviceDescString="serviceDesc";
	public static final String conceptString="concept";
	public static final String inputString="input";
	public static final String outputString="output";
	public static final String problemStructureString="problemStructure";
	public static final String solutionsString="solutions";
	public static final String solutionString="solution";
}
