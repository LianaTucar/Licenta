package validator;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import javax.xml.parsers.*;
import javax.xml.validation.Schema;

import org.w3c.dom.*;
import org.xml.sax.SAXException;


public class Wsc08 {
    public static HashMap<String,WebService> repository=new HashMap();
    public static Concept rootConcept;
    public static HashMap<String, Concept> conceptMap = new HashMap(), instanceMap = new HashMap();
    public static ArrayList<ServiceDesc> firstSequence = new ArrayList();
    public static HashSet<String> providedInstances, wantedInstances;
    public static HashMap<String, ArrayList<WebService>> instanceToServices = new HashMap<>(),  instanceToServicesOutput = new HashMap<>();
    
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, InterruptedException {
    	long startTime = System.currentTimeMillis();
    	String comun="wsc08\\04\\";
        //readServicesFile(comun+"services.xml");
        Thread threadReadServices = new Thread(new readServicesRunnable(comun+"services.xml", instanceToServices, instanceToServicesOutput, repository));
        threadReadServices.start();
        conceptMap = new HashMap<>();
        instanceMap = new HashMap<>();
        long startTax=System.currentTimeMillis();
        readTaxonomy(comun+"taxonomy.xml");
        System.out.println("tax: ");
        System.out.println(System.currentTimeMillis()-startTax);
        readProblemFile(comun+"problem.xml");
        //readProblemFile(comun+"test.xml");
        //readProblemFile("test1.xml");
        //boolean rez=Validator.isValid(repository, conceptMap, instanceMap, firstSequence, provided);
        //Node node = getFirstSolutionNodeFromProblemFile(comun+"problem.xml");
        //Node node = getFirstSolutionNodeFromProblemFile(comun+"test.xml");
        //Node node = getFirstSolutionNodeFromProblemFile("test1.xml");
        //System.out.println(node.getNodeName());
        /*boolean rez=Validator3.isValid(repository, new Taxonomy(conceptMap, instanceMap,rootConcept),(HashSet<String>) providedInstances.clone(), (HashSet<String>)wantedInstances.clone(), node);
        if (rez==true)
        	System.out.println("Valid!!");
        else
        	System.out.println("invalid");
        System.out.println(wantedInstances);
       */
        threadReadServices.join();
        Taxonomy taxonomy = new Taxonomy(conceptMap, instanceMap, rootConcept);
        Solver solver=new Solver(repository, instanceToServices, instanceToServicesOutput, taxonomy, (HashSet<String>)providedInstances.clone(), (HashSet<String>)wantedInstances.clone());
        ArrayList<ArrayList<WebService>> solution = solver.solve();
        ArrayList<ArrayList<String>> solutionNames = new ArrayList();
        for (ArrayList<WebService> level:solution){
        	ArrayList<String> levelNames=new ArrayList();
        	for (WebService service:level)
        		levelNames.add(service.getName());
        	solutionNames.add(levelNames);
        }
        System.out.println(System.currentTimeMillis()-startTime);
        XmlTranslator.createXml("test.xml", solutionNames, providedInstances, wantedInstances);
        Visualization visualization = new Visualization(taxonomy);
        visualization.visualize(solution);
    }
    
    public HashSet<Concept> intersect(HashSet<Concept> a, HashSet<Concept> b) {
        HashSet<Concept> inter = new HashSet<>();
        for (Concept c : a) {
            if (b.contains(c)) {
                inter.add(c);
            }
        }
        return inter;
    }
    public HashSet<Concept> getConceptsForInstance(String instance) {
        if (!instanceMap.containsKey(instance)) {
            return null;
        }
        HashSet<Concept> hs = new HashSet<>();
        Concept c = instanceMap.get(instance);
        while (c != null) {
            hs.add(c);
            c = c.getParent();
        }
        return hs;
    }
    
    public static void readTaxonomy(String filePath) throws SAXException, IOException, ParserConfigurationException {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        File xmlFile = new File(filePath);
        Document domDocument;
        domDocument = documentBuilder.parse(xmlFile);
        rootConcept = new Concept(domDocument.getFirstChild().getChildNodes().item(1));
        //rootConcept.printConteptInfo();
    }
    
    /*public static void readServicesFile(String filePath) throws ParserConfigurationException, SAXException, IOException {
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        File xmlFile = new File(filePath);
        Document domDocument;
        domDocument = documentBuilder.parse(xmlFile);
        
        NodeList serviceNodeList = domDocument.getElementsByTagName("service");

        repository = new HashMap<>();
        for (int i = 0; i < serviceNodeList.getLength(); i++) {
            Node node = serviceNodeList.item(i);
            Node inputNode = node.getChildNodes().item(1);
            Node outputNode = node.getChildNodes().item(3);
            HashSet <String> inps = ParserUtility.getNamesAttribute(inputNode,"instance");
            HashSet <String> outs = ParserUtility.getNamesAttribute(outputNode,"instance");
            String name = ((Element)node).getAttribute("name");
            WebService ws = new WebService(name,inps, outs);
            repository.put(name, ws);
            
            for(String inp:inps){
            	if (!instanceToServices.containsKey(inp))
            		instanceToServices.put(inp, new ArrayList<WebService>());
            	instanceToServices.get(inp).add(ws);
            }
            
            for (String out:outs){
            	if (!instanceToServicesOutput.containsKey(out))
            		instanceToServicesOutput.put(out, new ArrayList<WebService>());
            	instanceToServicesOutput.get(out).add(ws);
            }
        }
    }
    */
    public static Node getFirstSolutionNodeFromProblemFile(String filePath) throws ParserConfigurationException, SAXException, IOException {
    	DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    	DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    	File xmlFile = new File(filePath);
    	Document domDocument;
    	domDocument = documentBuilder.parse(xmlFile);
    	String[] names ={Constants.problemStructureString,Constants.solutionsString,Constants.solutionString};
    	Node firstNode = ParserUtility.getFirstsChildWithNames(domDocument, names).getChildNodes().item(1);// getFirstChild(); //?? sa nu fie ala #text
    	return firstNode;
    }
    
    public static void readProblemFile(String filePath) throws ParserConfigurationException, SAXException, IOException {
    	 DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
         DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
         File xmlFile = new File(filePath);
         Document domDocument;
         domDocument = documentBuilder.parse(xmlFile);
         /*String[] names ={"problemStructure","solutions","solution","sequence"};
         Node sequence = ParserUtility.getFirstsChildWithNames(domDocument, names);
         ArrayList<Node> serviceDescList = ParserUtility.getChildsWithName(sequence,"serviceDesc") ;
         for (int i = 0; i < serviceDescList.size(); i++) {
        	  firstSequence.add(new ServiceDesc(serviceDescList.get(i)));
          }*/
         String [] names2={"problemStructure","task","provided"};
         Node providedNode = ParserUtility.getFirstsChildWithNames(domDocument, names2);
         providedInstances = ParserUtility.getNamesAttribute(providedNode,"instance");
         String [] names3={Constants.problemStructureString,"task","wanted"};
         providedNode = ParserUtility.getFirstsChildWithNames(domDocument, names3);
         wantedInstances = ParserUtility.getNamesAttribute(providedNode,"instance");
    }
    
   
}
