package validator;


import java.util.ArrayList;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Concept {
    
    private String name;
    private Concept parent;
    private ArrayList<Concept> children;
    private ArrayList<String> instances;
    private int enterTimeInTaxonomyLinearization, exitTimeInTaxonomyLinearization;
    private int numberOfAscendantsInstances;
    
    public Concept(Node node) {
        name = node.getAttributes().getNamedItem("name").getTextContent();
        
        // don't set parent for this node, set in children
        
        children = new ArrayList();
        instances = new ArrayList<>();
        NodeList chs = node.getChildNodes();
        for (int i = 0; i < chs.getLength(); i++) {
            Node ch = chs.item(i);
            if (ch.getNodeName().equals("concept")) {
                Concept chConcept = new Concept(ch);
                children.add(chConcept);
                chConcept.setParent(this);
            }

            if (ch.getNodeName().equals("instance")) {
                String ins = ch.getAttributes().getNamedItem("name").getTextContent();
                instances.add(ins);
                Wsc08.instanceMap.put(ins, this);
            }
        }
        Wsc08.conceptMap.put(name, this);
        if (parent!=null)
        	numberOfAscendantsInstances=parent.getNumberOfAscendantsInstances()+parent.getInstances().size();
        else
        	numberOfAscendantsInstances=0;
    }
    
    public int getNumberOfAscendantsInstances() {
		return numberOfAscendantsInstances;
	}

	public int getEnterTimeInTaxonomyLinearization() {
		return enterTimeInTaxonomyLinearization;
	}

	public void setEnterTimeInTaxonomyLinearization(int enterTimeInTaxonomyLinearization) {
		this.enterTimeInTaxonomyLinearization = enterTimeInTaxonomyLinearization;
	}

	public int getExitTimeInTaxonomyLinearization() {
		return exitTimeInTaxonomyLinearization;
	}

	public void setExitTimeInTaxonomyLinearization(int exitTimeInTaxonomyLinearization) {
		this.exitTimeInTaxonomyLinearization = exitTimeInTaxonomyLinearization;
	}

	public void printConteptInfo() {
        System.out.println("Concept " + name + " parent " + parent);
        for (Concept ch : children) {
            System.out.print(ch.getName() + " ");
        } System.out.print("\n");

        for (String in : instances) {
            System.out.print(in + " ");
        } System.out.print("\n");
    }
    
    public Concept(String cName) {
        name = cName;
    }

    public String getName() {
        return name;
    }

    public Concept getParent() {
        return parent;
    }

    public void setParent(Concept parent) {
        this.parent = parent;
    }

    public ArrayList<Concept> getChildren() {
        return children;
    }

    public void setChildren(ArrayList<Concept> children) {
        this.children = children;
    }

    public ArrayList<String> getInstances() {
        return instances;
    }

    public void setInstances(ArrayList<String> instances) {
        this.instances = instances;
    }
}
