package validator;

import java.util.HashMap;
import java.util.HashSet;

public class Taxonomy {
	private HashMap<String, Concept> conceptMap;
	private static HashMap<String, Concept> instanceMap;
	private Concept rootConcept;
	private int time;
	
	public Taxonomy(HashMap<String, Concept> conceptMap, HashMap<String, Concept> instanceMap, Concept rootConcept){
		this.conceptMap=conceptMap;
		this.instanceMap=instanceMap;
		this.rootConcept=rootConcept;
		linearizeAndCalculateEnterAndExitTimes();
	}
	
	void dfs(Concept concept){
		time++;
		concept.setEnterTimeInTaxonomyLinearization(time);
		for (Concept subConcept:concept.getChildren())
			dfs(subConcept);
		time++; //aici am facut ultima modificare !!!!!!!!!!!!!!!!
		concept.setExitTimeInTaxonomyLinearization(time);
	}
	
	private void linearizeAndCalculateEnterAndExitTimes(){
		time=0;
		dfs(rootConcept);
	}
	
	public Concept getConceptWithName(String name){
		return conceptMap.get(name);
	}
	
	public Concept getInstanceWithName(String name){
		return instanceMap.get(name);
	}
	
	/*public HashSet<String> getNewAncestorsConcepts(String instanceName, HashSet<String> ownedConcepts){
		HashSet<String> newAncestorsConcepts =(HashSet<String>) ownedConcepts.clone();
		Concept concept = instanceMap.get(instanceName).getParent(); //?????????
		while (true){
			if (!(newAncestorsConcepts.contains(concept.getName()))){
				newAncestorsConcepts.add(concept.getName());
				if (concept.getParent()!=null)
					concept=concept.getParent();
				else
					break;
			}else
				break;
		}
		return newAncestorsConcepts;
	}
	
	public HashSet<String> getNewAncestorsInstances(String instanceName, HashSet<String> ownedConcepts){
		HashSet<String> newAncestorsConcepts = getNewAncestorsConcepts(instanceName, ownedConcepts);
		HashSet<String> newAncestorsInstances = new HashSet();
		newAncestorsInstances.add(instanceName);
		for (String concept:newAncestorsConcepts)
			newAncestorsInstances.addAll(getConceptWithName(concept).getInstances());
		return newAncestorsInstances;
	}*/
	
	public HashSet<String> getNewAncestorsInstances(String instanceName, HashSet<String> ownedInstances){
		HashSet<String> newAncestorsInstances =new HashSet();
		Concept concept = instanceMap.get(instanceName); //aici era si Parent cred ?????????
		while (true){
			boolean gasit=false;
			for (String instance:concept.getInstances())
				if (!(ownedInstances.contains(instance))){
					newAncestorsInstances.add(instance);
				}else
					gasit=true;
			if (gasit)
				break;
			if (concept.getParent()!=null)
				concept=concept.getParent();
			else
				break;
		}
		if (!ownedInstances.contains(instanceName))
			newAncestorsInstances.add(instanceName);
		return newAncestorsInstances;
	}
	
	public void addNewDescendantsInstances(String instanceName, HashSet<String> ownedInstances){
		Concept concept=instanceMap.get(instanceName);
		for (Concept child:concept.getChildren())
			addNewDescendantsInstancesFromConcept(child,ownedInstances);
		ownedInstances.add(instanceName);
	}
	
	public void addNewDescendantsInstancesFromConcept(Concept concept, HashSet<String> ownedInstances){
		HashSet<String> intersection=new HashSet<>();
		intersection.addAll(concept.getInstances());
		intersection.retainAll(ownedInstances);
		if (intersection.size()>0){
			ownedInstances.addAll(concept.getInstances());
			return;
		}
		for (Concept child:concept.getChildren())
			addNewDescendantsInstancesFromConcept(child,ownedInstances);
		ownedInstances.addAll(concept.getInstances());
	}
	//de pus functie care marcheaza anumite concepte
	
	/*public boolean subsumes(String instanceA, String instanceB){ //O(inaltime taxonomie)
		Concept conceptA=instanceMap.get(instanceA);
		Concept conceptB=instanceMap.get(instanceB);
		while ((conceptB!=null)&&(!conceptB.equals(conceptA)))
			conceptB=conceptB.getParent();
		return conceptB!=null;
	}*/
	
	public boolean subsumes(String instanceA, String instanceB){ //O(1)
		Concept conceptA=instanceMap.get(instanceA);
		Concept conceptB=instanceMap.get(instanceB);
		return (conceptA.getEnterTimeInTaxonomyLinearization()<=conceptB.getEnterTimeInTaxonomyLinearization()) &&
			   (conceptB.getExitTimeInTaxonomyLinearization()<=conceptA.getExitTimeInTaxonomyLinearization());
	}
	
	public boolean subsumes(HashSet<String> A, HashSet<String> B){
		for (String instanceToCover:A){
			boolean covered=false;
			for (String instance:B)
				if (subsumes(instanceToCover,instance)){
					covered=true;
					break;
				}
			if (!covered)
				return false;
		}
		return true;
	}
	
	public boolean subsumes(String A, HashSet<String> B){
		HashSet <String>hs=new HashSet();
		hs.add(A);
		return subsumes(hs,B);
	}
	
	public void keepOnlyInstances(HashSet<String> instances){
		for (String conceptName:conceptMap.keySet()){
			Concept concept=conceptMap.get(conceptName);
			concept.getInstances().retainAll(instances);
		}
		instanceMap.keySet().retainAll(instances); //care-i faza cu asta?????????????????///////
	}
	
	public static int getOutputScore(String instace){
		return instanceMap.get(instace).getNumberOfAscendantsInstances();
	}
}
