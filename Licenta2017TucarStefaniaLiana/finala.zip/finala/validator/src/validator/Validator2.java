package validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Validator2 {
	public static HashSet<String> isValidSeqence(HashMap<String,WebService> repository, HashMap<String, Concept> conceptMap, HashMap<String, Concept> instanceMap,ArrayList<ServiceDesc> sequence, HashSet<String> providedInstances){
		HashSet<String> obtainedInstances, markedConcepts, newObtainedInstances;
		obtainedInstances=new HashSet();
		newObtainedInstances=new HashSet();
		//obtainedInstances.addAll(providedInstances);
		markedConcepts=new HashSet();
		for (String instanceName:providedInstances){
			//addSubconcepts(instanceMap.get(instanceName).getParent());
			addAncestor(markedConcepts,obtainedInstances,instanceMap.get(instanceName));
		}	
		int index=0;
		for (ServiceDesc serviceDesc:sequence){
			index++;
			String serviceName=serviceDesc.getRealizationsServices().get(0);
			WebService service=repository.get(serviceName);
			for (String input:service.getInputs())
				if (!obtainedInstances.contains(input))
					return null;
			for (String output:service.getOutputs()){
				//addSubconcepts(instanceMap.get(output).getParent());
				addAncestor(markedConcepts,obtainedInstances,instanceMap.get(output));
				obtainedInstances.add(output);
			}
		}
		return obtainedInstances;
	}
	/*
	public static HashSet<String>  isValidParallel(HashMap<String,WebService> repository, HashMap<String, Concept> conceptMap,HashMap<String, Concept> instanceMap, ArrayList<ServiceDesc> sequence, HashSet<String> providedInstances){
		HashSet<String> obtainedInstances, markedConcepts;
		obtainedInstances=new HashSet();
		//obtainedInstances.addAll(providedInstances);
		markedConcepts=new HashSet();
		for (String instanceName:providedInstances){
			//addSubconcepts(instanceMap.get(instanceName).getParent());
			addAncestor(instanceMap.get(instanceName));
		}	
		int index=0;
		for (ServiceDesc serviceDesc:sequence){
			index++;
			String serviceName=serviceDesc.getRealizationsServices().get(0);
			WebService service=repository.get(serviceName);
			for (String input:service.getInputs())
				if (!obtainedInstances.contains(input))
					return null;
			for (String output:service.getOutputs()){
				//addSubconcepts(instanceMap.get(output).getParent());
				addAncestor(instanceMap.get(output));
				obtainedInstances.add(output);
			}
		}
		return obtainedInstances;
	}
	*/
	private static void addAncestor(HashSet<String> markedConcepts, HashSet<String> obtainedInstances, Concept concept){
		if (!(markedConcepts.contains(concept.getName()))){
			markedConcepts.add(concept.getName());
			obtainedInstances.addAll(concept.getInstances());
			if (concept.getParent()!=null)
				addAncestor(markedConcepts,obtainedInstances,concept.getParent());
		}
	}
	
	/*private static void addSubconcepts(Concept concept){
		if (!markedConcepts.contains(concept.getName())){
			markedConcepts.add(concept.getName());
			obtainedInstances.addAll(concept.getInstances());
			for (Concept child:concept.getChildren())
				addSubconcepts(child);
		}
	}*/
}
