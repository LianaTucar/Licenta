package validator;

import java.util.ArrayList;
import java.util.HashSet;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;

public class XmlTranslator {
	public static void createXml(String fileName, ArrayList<ArrayList<String>> servicesSequence, HashSet<String> providedInstances, HashSet<String> wantedInstances){
		try{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.newDocument();
			Element rootElement = doc.createElement(Constants.problemStructureString);
			doc.appendChild(rootElement);
			Element task = doc.createElement("task");
			Element provided=doc.createElement("provided");
			Element wanted=doc.createElement("wanted");
			for (String instance:providedInstances){
				Element instanceElement= doc.createElement("instance");
				instanceElement.setAttribute("name", instance);
				provided.appendChild(instanceElement);
			}
			for (String instance:wantedInstances){
				Element instanceElement= doc.createElement("instance");
				instanceElement.setAttribute("name", instance);
				wanted.appendChild(instanceElement);
			}
			task.appendChild(provided);
			task.appendChild(wanted);
			rootElement.appendChild(task);
			
			Element solutions = doc.createElement(Constants.solutionsString);
			rootElement.appendChild(solutions);
			Element solution = doc.createElement(Constants.solutionString);
			solutions.appendChild(solution);
			Element sequence = doc.createElement(Constants.sequenceString);
			for (ArrayList<String> parallel:servicesSequence){
				Element parallelElement=doc.createElement(Constants.parallelString);
				for (String serviceName:parallel){
					Element serviceDesc=doc.createElement(Constants.serviceDescString);
					Element abstraction = doc.createElement("abstraction");
					abstraction.appendChild(doc.createElement(Constants.inputString));
					abstraction.appendChild(doc.createElement(Constants.outputString));
					Element realizations = doc.createElement("realizations");
					Element service = doc.createElement("service");
					service.setAttribute("name", serviceName);
					realizations.appendChild(service);
					serviceDesc.appendChild(abstraction);
					serviceDesc.appendChild(realizations);
					parallelElement.appendChild(serviceDesc);
				}
				sequence.appendChild(parallelElement);
			}
			solution.appendChild(sequence);
			
			TransformerFactory transformerFactory =TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(fileName));
			transformer.transform(source, result);
		}catch (Exception e) {
	         e.printStackTrace();
	      }
	}
}
