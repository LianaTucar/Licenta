package validator;

import java.util.ArrayList;
import java.util.HashSet;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ParserUtility {
	   public static Node getFirstChildWithName(Node node, String name){ //primul copil cu un anumit nume
	    	NodeList childs = node.getChildNodes();
	    	int lg=childs.getLength();
	    	for (int i=0;i<lg;i++){
	    		String nodeName=childs.item(i).getNodeName();
	    		if ((nodeName!=null) && (nodeName.equals(name)))
	    			return childs.item(i);
	    	}
	    	return null;
	    }
	    
	    public static ArrayList<Node> getChildsWithName(Node node, String name){ //toti copiii directi cu un anumit nume
	    	NodeList childs=node.getChildNodes();
	    	ArrayList<Node> childsWithName = new ArrayList();
	    	for (int i=0;i<childs.getLength();i++){
	    		String nodeName=childs.item(i).getNodeName();
	    		if ((nodeName!=null) && (nodeName.equals(name)))
	    			childsWithName.add(childs.item(i));
	    	}
	    	return childsWithName;
	    }
	    
	    public static Node getFirstsChildWithNames(Node node, String [] names){ 
	    	//names e lista de nume si se returneaza primul copil al primului copil...al primului copil cu numele in ordinea din "names"
	    	for (String name:names){
	    		node=getFirstChildWithName(node,name);
	    	}
	    	return node;
	    }
	    
	    public static HashSet<String> getNamesAttribute(Node xmlNode, String name) {
	        HashSet<String> pars = new HashSet<>();
	        NodeList childList = xmlNode.getChildNodes();
	        for (int i = 0; i < childList.getLength(); i++) {
	            Node child = childList.item(i);
	            if (child.getNodeName().equals(name)) {
	                pars.add(child.getAttributes().getNamedItem("name").getNodeValue());
	            }
	        }
	        return pars;
	    }
}
