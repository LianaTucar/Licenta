package validator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.TreeSet;
import java.util.Vector;

public class Solver {
	public static int totalMarkTime=0;
	private static HashMap<String,WebService> repository;
	private static HashMap<String, ArrayList<WebService>> instanceToServices, instanceToServicesOutputs;
	private static Taxonomy taxonomy;
	private HashSet<String> providedInstances, wantedInstances, ownedInstances;
	private static HashSet<WebService> servicesReadyToCall;
	private ArrayList<ArrayList<WebService>> result2;
	private int totalNumberOfServices;
	long totalMark=0;
	
	public Solver(HashMap<String,WebService> repository, HashMap<String, ArrayList<WebService>> instanceToServices, HashMap<String, ArrayList<WebService>> instanceToServicesOutputs, Taxonomy taxonomy, HashSet<String> providedInstances, HashSet<String> wantedInstances){
		this.repository=repository;
		this.instanceToServices=instanceToServices;
		this.instanceToServicesOutputs=instanceToServicesOutputs;
		this.taxonomy=taxonomy;
		this.providedInstances=providedInstances;
		this.wantedInstances=wantedInstances;
	}

	//scris in pseudocod
	public ArrayList<ArrayList<WebService>> solve(){
		boolean firstTime=true;
		int total, anteriorTotal=0,totalFindSolutionTime=0;
		while (true){
			long startTime = System.currentTimeMillis();
			findASolution();
			
			totalFindSolutionTime+=System.currentTimeMillis()-startTime;
			resetNeededInputsAndNewOutputsFromRepository();
			firstTime=false;
			HashSet<String> usefulInstances=keepOnlyUsefulServicesAndInstances(result2);
			
			if (!firstTime) //cu sau fara chestia asta???????????????????????????????????????????????
				keepOnlyServicesFromSolution(result2); //cu sau fara asta? 	
			
			reduceTheProblem(usefulInstances);
			
			total=totalNumberOfServices;
			if (total==anteriorTotal)
				break;
			anteriorTotal=total;
		
		}
		evalueazaSolutia(result2);
		System.out.println(totalFindSolutionTime+" total find solution time");
		System.out.println(totalMarkTime+" total mark time");
		return result2;
	}
	
	//scris in pseudocod intr-o linie
	private void keepOnlyServicesFromSolution(ArrayList<ArrayList<WebService>> solution){
		HashSet<WebService> services = new HashSet();
		HashSet<String> servicesNames = new HashSet();
		for (int index=0;index<solution.size();index++)
			services.addAll(solution.get(index));
		for (WebService service:services)
			servicesNames.add(service.getName());
		repository.keySet().retainAll(servicesNames);
		for (ArrayList<WebService>servicesWithInstance:instanceToServices.values())
			servicesWithInstance.retainAll(services);
		for (ArrayList<WebService>servicesWithInstaceOutputs:instanceToServicesOutputs.values())
			servicesWithInstaceOutputs.retainAll(services);
	}
	
	private void evalueazaSolutia(ArrayList<ArrayList<WebService>> solution){
		int nrTotal=0;
		System.out.println("sol finala nr pe nivel");
		for (int index=0;index<solution.size();index++){
			ArrayList<WebService> level=solution.get(index);
			nrTotal+=level.size();
			//System.out.println(level.size());
		}
		System.out.println("solutie finala: "+nrTotal+" servicii si "+solution.size()+" nivele");
	}
	//pseudocod: rezumat in mai putin de o linie
	private void reduceTheProblem(HashSet<String> instances){
		for (Map.Entry<String, WebService> entry : repository.entrySet()){
			WebService service=entry.getValue();
			//service.getInputs().retainAll(instances);
			removeUseless(service.getOutputs(),instances); //DE CE chestia asta schimba rezultatul???????????
			//service.getNeededInputs().retainAll(instances);
			removeUseless(service.getNewOutputs(),instances);
			//service.resetNeededInputsAndNewOutputs();
			//service.setNeededInputs((HashSet<String>)service.getInputs().clone());
		}
	}
	//pseudocod: rezumat in mai putin de o linie
	private void removeUseless(HashSet<String>list, HashSet<String> usefulInstances){
		HashSet<String> toRemove=new HashSet<>();
		for (String instance:list){
			boolean gasit=false;
			for (String usefulInstance:usefulInstances)
				if (taxonomy.subsumes(usefulInstance,instance)){ //asa sau invers??????????????????????????????????????????
					gasit=true;
					break;
				}
			if (!gasit)
				toRemove.add(instance);
		}
		list.removeAll(toRemove);
	}
	
	//scris in pseudocod
	private void mark(HashSet<String> instances, WebService service){
		long startTime = System.currentTimeMillis();
		for (String instance:instances){
			markServicesWithInstanceAsInput(instance);
			markServicesWithInstanceAsOutputExceptService(instance,service);
		}
		totalMarkTime+=System.currentTimeMillis()-startTime;
		
	}
	
	//scris in pseudocod
	private void obtainFirstLayer(){
		for (String instanceName:providedInstances){
			HashSet<String> instancesObtained=taxonomy.getNewAncestorsInstances(instanceName, ownedInstances);
			ownedInstances.addAll(instancesObtained);
			mark(instancesObtained,null);
		}
	}
	
	private void initialization(){
		ownedInstances=new HashSet<>();
		result2=new ArrayList();
		servicesReadyToCall = new HashSet<>();
	}
	
	//scris in pseudocod
	private void addServiceToLayer(WebService service, ArrayList<WebService> parallel){
		parallel.add(service);
		for (String instanceName:service.getNewOutputs()){
			HashSet<String> instancesObtained=taxonomy.getNewAncestorsInstances(instanceName, ownedInstances);
			ownedInstances.addAll(instancesObtained);
			/*for (WebService service1:servicesToCall) //cum merge fara chestia asta?????
				service1.removeFromNewOutputs(instancesObtained); //de optimizat*/
			wantedInstances.removeAll(instancesObtained);
			mark(instancesObtained,service);
		}
	}
	
	//scris in pseudocod
	private void findASolution(){
		initialization();
		HashSet<String> wantedInstancesCopy =(HashSet<String>) wantedInstances.clone();
		obtainFirstLayer();
		boolean firstTime=true;
		while ((wantedInstances.size()>0)&&(servicesReadyToCall.size()>0)){
			firstTime=false;
			long startWhile=System.currentTimeMillis();
			ArrayList<WebService> parallel = new ArrayList();
			ArrayList<WebService> servicesToCall = new ArrayList();
			servicesToCall.addAll(servicesReadyToCall);
			servicesReadyToCall.clear();
			while (servicesToCall.size()>0){
				WebService maximum=Collections.max(servicesToCall);
				WebService service=maximum;
				servicesToCall.remove(maximum);
				//if (!ownedInstances.containsAll(service.getOutputs()))  //aici am comentat dupa ultima testare <--------------------------------------------------
					if (!taxonomy.subsumes(service.getNewOutputs(),ownedInstances)){
						addServiceToLayer(service, parallel);
					}
			}
			if (parallel.size()>0)
				result2.add(parallel);
		} 
		/*System.out.println("nr servicii: "+ dimTotala+ " adancime: "+nrWhile);
		if (wantedInstances.size()==0){
			System.out.println("victorie !!!");
		}else
			System.out.println("ghinion");*/
		wantedInstances=(HashSet<String>)wantedInstancesCopy.clone();
	}
	
	private void resetNeededInputsAndNewOutputsFromRepository(){
		for (Map.Entry<String, WebService> entry : repository.entrySet()){//n-ar trebui resetat dupa removeUseless?
			WebService service=entry.getValue();
			service.resetNeededInputsAndNewOutputs();
		}
	}
	
	//partea asta de paralelizat _________________________________________________________________________________________
	//scris in pseudocod -> f sumar
	public static void markServicesWithInstanceAsInput(String instanceName){
		ArrayList<WebService> servicesWithInsAsInput=instanceToServices.get(instanceName);
		if (servicesWithInsAsInput!=null)
			for (WebService service:servicesWithInsAsInput){
				if (service.removeNeededInput(instanceName))
					if (service.getNumberOfNeddedInputs()==0){
						servicesReadyToCall.add(service);
					}
				}
	}
	//scris in pseudocod -> f sumar
	public static void markServicesWithInstanceAsOutputExceptService(String instanceName, WebService exceptService){
		ArrayList<WebService> servicesWithInsAsOutput=instanceToServicesOutputs.get(instanceName);
		if(servicesWithInsAsOutput!=null)
			for (WebService service:servicesWithInsAsOutput)
				if ((exceptService==null) || (!service.equals(exceptService))){
					service.removeFromNewOutputs(instanceName);
				}
	}
	
	//partea asta de paralelizat _________________________________________________________________________________________
	
	
	private HashSet<String> keepOnlyUsefulServicesAndInstances(ArrayList<ArrayList<WebService>> solution){
		HashSet<String> usefulInstances = new HashSet<>(), toFindInstances=new HashSet<>(), ownedInstances=new HashSet<>();
		totalNumberOfServices=0;
		usefulInstances.addAll(wantedInstances);
		toFindInstances.addAll(wantedInstances);
		ArrayList<String> instToRemove=new ArrayList();
		for (String inst:toFindInstances)
			for (String prI:providedInstances)
				if (taxonomy.subsumes(inst,prI)){
					instToRemove.add(inst);
					break;
				}
		toFindInstances.removeAll(instToRemove);
		//usefulInstances.removeAll(instToRemove);
		for (int index=solution.size()-1;index>=0;index--){
			ArrayList<WebService> level = solution.get(index);
			ArrayList<WebService> servicesToRemove = new ArrayList<>();
			HashSet<String> usefulForLevel=new HashSet();
			
			//Collections.sort(level);//<-------------------------*
			for (WebService service:level){
				instToRemove = new ArrayList();
				HashSet<String> outs=service.getOutputs(); //aici am pus new
				boolean gasit=false;
				for (String out:outs){
					for (String instance:toFindInstances)
						if (taxonomy.subsumes(instance,out)){
							gasit=true;
							instToRemove.add(instance);
						}
				}
				if (!gasit)
					servicesToRemove.add(service);
				else{
					for (String inp:service.getInputs()){
						boolean gasit1=false;
						for (String pr:providedInstances)
							if (taxonomy.subsumes(inp,pr)){
								gasit1=true;
								break;
							}
						if (!gasit1)
							usefulForLevel.add(inp);					
					}
				}
				toFindInstances.removeAll(instToRemove);
				
			}
			level.removeAll(servicesToRemove);
			toFindInstances.addAll(usefulForLevel);
			usefulInstances.addAll(usefulForLevel);
			totalNumberOfServices+=level.size();
		}
		//taxonomy.keepOnlyInstances(usefulInstances); // cu sau fara asta pare ca da la fel timpul ???????????????????????????????????
		//providedInstances.retainAll(usefulInstances); //si aici dc nu e bn???????///
		return usefulInstances;
	}
	

	
}
