package validator;

import java.util.ArrayList;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ServiceDesc {
	private ArrayList <String> inputConcepts, outputConcepts, realizationsServices;
	
	public ServiceDesc(ArrayList <String> inputConc, ArrayList <String> outputConc, ArrayList <String> realizationServ){
		inputConcepts=(ArrayList<String>) inputConc.clone();
		outputConcepts=(ArrayList<String>) outputConc.clone();
		realizationsServices=(ArrayList<String>) realizationServ.clone();
	}
	
	public ServiceDesc(Node node){
		Node abstractionNode = ParserUtility.getFirstChildWithName(node, "abstraction");
		inputConcepts = namesList(ParserUtility.getFirstChildWithName(abstractionNode, "input"));
		outputConcepts = namesList(ParserUtility.getFirstChildWithName(abstractionNode, "output"));///getLastChild());
		Node realizationNode = ParserUtility.getFirstChildWithName(node, "realizations");
		realizationsServices = namesList(realizationNode);
	}
	
	private ArrayList<String> namesList(Node node){
		NodeList chs = node.getChildNodes();
		ArrayList<String> list= new ArrayList();
		for (int i = 0; i < chs.getLength(); i++) {
			Node ch = chs.item(i);
			if (ch.hasAttributes())
				list.add(((Element)ch).getAttribute("name"));
		}
		return list;
	}
	
	public String toString(){
		return "inputs: "+inputConcepts.toString()+" outputs: "+outputConcepts.toString()+" realizations: "+realizationsServices.toString(); 
	}
	
	public ArrayList<String> getRealizationsServices() {
		return realizationsServices;
	}

	public ArrayList<String> getInputConcepts() {
		return inputConcepts;
	}

	public ArrayList<String> getOutputConcepts() {
		return outputConcepts;
	}
	
}
