package validator;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class readServicesRunnable implements Runnable{
	private String filePath;
	private HashMap<String,WebService> repository;
	private HashMap<String, ArrayList<WebService>> instanceToServices, instanceToServicesOutput;

	public readServicesRunnable(String filePath, HashMap<String, ArrayList<WebService>> instanceToServices, HashMap<String, ArrayList<WebService>> instanceToServicesOutput, HashMap<String,WebService> repository){
		this.filePath=filePath;
		this.repository=repository;
		this.instanceToServices=instanceToServices;
		this.instanceToServicesOutput=instanceToServicesOutput;
	}

	public void run(){
		try{
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			File xmlFile = new File(filePath);
			Document domDocument;
			domDocument = documentBuilder.parse(xmlFile);
	
			NodeList serviceNodeList = domDocument.getElementsByTagName("service");
	
			for (int i = 0; i < serviceNodeList.getLength(); i++) {
				Node node = serviceNodeList.item(i);
				Node inputNode = node.getChildNodes().item(1);
				Node outputNode = node.getChildNodes().item(3);
				HashSet <String> inps = ParserUtility.getNamesAttribute(inputNode,"instance");
				HashSet <String> outs = ParserUtility.getNamesAttribute(outputNode,"instance");
				String name = ((Element)node).getAttribute("name");
				WebService ws = new WebService(name,inps, outs);
				repository.put(name, ws);
	
				for(String inp:inps){
					if (!instanceToServices.containsKey(inp))
						instanceToServices.put(inp, new ArrayList<WebService>());
					instanceToServices.get(inp).add(ws);
				}
	
				for (String out:outs){
					if (!instanceToServicesOutput.containsKey(out))
						instanceToServicesOutput.put(out, new ArrayList<WebService>());
					instanceToServicesOutput.get(out).add(ws);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
