package validator;

import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;
import org.graphstream.ui.graphicGraph.GraphicGraph;
import org.graphstream.ui.graphicGraph.stylesheet.StyleConstants.Units;
import org.graphstream.ui.spriteManager.Sprite;
import org.graphstream.ui.spriteManager.SpriteManager;
import org.graphstream.ui.view.View;
import org.graphstream.ui.view.Viewer;

public class Visualization {
	private ArrayList<ArrayList<WebService>>data;
	private ArrayList<Node> inputNodes=new ArrayList(), outputNodes=new ArrayList();
	private HashMap<String,Integer> lastLayer=new HashMap(), layer=new HashMap();
	private Graph graph;
	private Taxonomy taxonomy;
	private double x=0, y=0, z=0,w=0;
	
	Visualization(Taxonomy taxonomy){
		this.taxonomy=taxonomy;
		graph = new SingleGraph("tutorial 1");
		System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.j2dviewer.J2DGraphRenderer");
		graph.addAttribute("ui.stylesheet", "url(stylesheet)");
		graph.setStrict(false);
	}
	
	private void findLastLayerOfEveryInstanceOutput(){
		int layerNumber=0;
		for (ArrayList<WebService>layer:data){
			for(WebService service:layer)
				for (String outputInstance:service.getNewOutputs())
					lastLayer.put("O"+outputInstance.substring("serv".length()), layerNumber);
			layerNumber+=1;
		}
	}
	
	private void drawServices(){
		double x=0, y=0, z=0,w=0;
		for (ArrayList<WebService> layer:data){
			x+=2;	y=1;
			for (WebService service:layer){
				w+=1;
				String serviceLabelName=service.getName().substring("serv".length());
				graph.addNode(serviceLabelName);
				Node serviceNode= graph.getNode(serviceLabelName);
				serviceNode.addAttribute("label", serviceLabelName);
				serviceNode.setAttribute("xyz",x,y,z);
				serviceNode.addAttribute("ui.class", "service");
				y+=0.6;
			}
		}
	}
	
	private double drawOutputs(double startY, HashSet<String> outputInstances,Node serviceNode, String serviceLabelName, int layerNumber){
		double y=startY;
		for (String output:outputInstances){
			String instanceLabelName="O"+output.substring("inst".length());
			Node instanceNode;
			if (lastLayer.get(instanceLabelName)==layerNumber){
				graph.addNode(instanceLabelName);
				instanceNode= graph.getNode(instanceLabelName);
				layer.put(instanceLabelName, layerNumber);
				instanceNode.addAttribute("layout.frozen");
				instanceNode.addAttribute("label", instanceLabelName);
				instanceNode.addAttribute("ui.class", "outputInstance");
				outputNodes.add(instanceNode);
				instanceNode.setAttribute("xyz",x+5.5,y,z);
			}else{
				instanceNode= graph.getNode(instanceLabelName);
			}
			y+=1;
			graph.addEdge(serviceLabelName+" "+instanceLabelName,serviceNode, instanceNode,true);
		}
		return y;
	}
	
	private double drawInputs(double startY, HashSet<String> inputInstances,Node serviceNode, String serviceLabelName, int layerNumber){
		double y=startY;
		for (String input:inputInstances){
			String instanceLabelName="I"+input.substring("inst".length());
			Node instanceNode;
			
				graph.addNode(instanceLabelName);
				instanceNode= graph.getNode(instanceLabelName);
				layer.put(instanceLabelName, layerNumber);
				instanceNode.addAttribute("layout.frozen");
				instanceNode.addAttribute("label", instanceLabelName);
				instanceNode.addAttribute("ui.class", "inputInstance");
				instanceNode.setAttribute("xyz",x-5.5,y,z);
			inputNodes.add(instanceNode);
			y+=2;
			graph.addEdge(instanceLabelName+" "+serviceLabelName,instanceNode,serviceNode,true);
		}
		return y;
	}
	
	private void drawSubsumesEdges(){
		for (Node outputNode:outputNodes){
			String outputName="inst"+outputNode.getId().substring(1);
			for (Node inputNode:inputNodes){
				String inputName="inst"+inputNode.getId().substring(1);
				if (taxonomy.subsumes(inputName,outputName))
					if (layer.get(outputNode.getId())<layer.get(inputNode.getId())){
						//System.out.println(outputName+"->"+inputName);
						Edge e = graph.addEdge(outputName+" "+inputName,outputNode,inputNode,true);
						e.addAttribute("ui.class", "subsumesEdge");
					}
			}
		}
	}
	
	public void visualize( ArrayList<ArrayList<WebService>> data){
		this.data=data;
		y=z=0;
		x=20;
		ArrayList<String> instances=new ArrayList();
		findLastLayerOfEveryInstanceOutput();
		//drawServices();
		for (int layerIndex=data.size()-1;layerIndex>=0;layerIndex--){
			ArrayList<WebService> layer=data.get(layerIndex);
			x-=20;	y=1;
			for (WebService service:layer){
				String serviceLabelName=service.getName().substring("serv".length());
				graph.addNode(serviceLabelName);
				Node serviceNode= graph.getNode(serviceLabelName);
				double firstY=y;
				double lastY=drawOutputs(y,service.getNewOutputs(),serviceNode,serviceLabelName,layerIndex);
				lastY=Math.max(lastY,drawInputs(y,service.getInputs(),serviceNode,serviceLabelName,layerIndex));
				serviceNode.addAttribute("layout.frozen");
				serviceNode.addAttribute("label", serviceLabelName);
				//serviceNode.setAttribute("xyz",x,(firstY+lastY)/2,z);
				serviceNode.setAttribute("xyz",x,y,z);
				serviceNode.addAttribute("ui.class", "service");
				y+=10;
				
			}
		}
		drawSubsumesEdges();
		Viewer viewer = graph.display();
		View view = viewer.getDefaultView();
		float x=0, y, z;
		/*for (Node node:graph.getNodeSet()){
			System.out.println(node.getAttribute("xyz").toString());
			
		}*/
		
		view.addMouseListener(new MyMouseListener());
		
		/*System.setProperty("org.graphstream.ui.renderer", "org.graphstream.ui.swingViewer.GraphRenderer");
		Graph graph = new SingleGraph("I can see dead pixels");
		Viewer viewer = graph.display();
*/
		//Viewer viewer = graph.display();
		//View view = viewer.getDefaultView();
		//Viewer viewer = new Viewer(graph, Viewer.ThreadingModel.GRAPH_IN_GUI_THREAD);
		// ...
		//View view = viewer.addDefaultView(false);   // false indicates "no JFrame".
		
		//JFrame frame = new JFrame();
        //frame.add((Component)view);
		/*Viewer viewer = new Viewer(graph, Viewer.ThreadingModel.GRAPH_IN_GUI_THREAD);
		// ...
		View view = viewer.addDefaultView(false);   // false indicates "no JFrame".
		// ...
		JFrame frame = new JFrame();
        frame.add((Component)view);
        /*
		
		JScrollPane scrollPane = new JScrollPane();

		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		//scrollPane.add((Component) view);
		scrollPane.setViewportView((Component)view);
		 JPanel contentPane = new JPanel(null);
		contentPane.add(scrollPane);
		 contentPane.setPreferredSize(new Dimension(500, 400));
	        contentPane.add(scrollPane);
	        frame.setContentPane(contentPane);
	        frame.pack();
	        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        frame.setVisible(true);
		*/
		
	}
}
